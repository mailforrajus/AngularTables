import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { IndexComponent } from './components/index/index.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { RouterModule } from '@angular/router';
import { appRoutes, dashBoardLazyLoad } from './Routings/app.routes';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { LoginComponent } from './components/login/login.component';
import { SinupComponent } from './components/sinup/sinup.component';
import { SinUpService } from './services/sinUp.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    IndexComponent,
    LoginComponent,
    SinupComponent,

  ],
  imports: [
    BrowserModule, dashBoardLazyLoad, ReactiveFormsModule, FormsModule, HttpClientModule
  ],
  providers: [SinUpService],
  bootstrap: [IndexComponent]
})
export class AppModule { }
