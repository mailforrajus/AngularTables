import { NgModule } from "@angular/core";
import { DashboardComponent } from "../components/dashboard/dashboard.component";
import { AboutusComponent } from "../components/aboutus/aboutus.component";
import { ContactusComponent } from "../components/contactus/contactus.component";
import { HomeComponent } from "../components/home/home.component";
import { CommonModule } from "@angular/common";
import { Routes, RouterModule } from "@angular/router";
import {  ReactiveFormsModule } from "@angular/forms";

export const dashboardRoutes: Routes = [{

    path: "", component: DashboardComponent,
    children: [{
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    { path: "home", component: HomeComponent },
    { path: "aboutUs", component: AboutusComponent },
    { path: "contactUs", component: ContactusComponent }]
}
]

@NgModule({
    declarations: [DashboardComponent, AboutusComponent, ContactusComponent, HomeComponent],
    imports: [CommonModule, RouterModule.forChild(dashboardRoutes), ReactiveFormsModule],
    providers: [],
    exports: [DashboardComponent]
})
export class dashboardModule { }