import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";


@Injectable()

export class SinUpService {
    constructor(private _httpClient: HttpClient) { }

    public saveInfoInDatabase(register: any): any {

        return this._httpClient.post("http://localhost:8081/restApi/saveInfo", register);

    }

    public getCountryList(): any {
        return this._httpClient.get("http://localhost:8081/Rest/API/getAllCountryList");
    };
    public getStatesInfo(obj): any {
        return this._httpClient.post("http://localhost:8081/Rest/API/getAllStateDetails", obj);
    }

}
