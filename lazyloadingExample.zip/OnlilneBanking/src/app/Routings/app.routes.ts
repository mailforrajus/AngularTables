import {  Routes, RouterModule } from "@angular/router";
import { DashboardComponent } from "../components/dashboard/dashboard.component";
import { LoginComponent } from "../components/login/login.component";
import { ModuleWithProviders } from "@angular/compiler/src/core";
import { SinupComponent } from "../components/sinup/sinup.component";

export const appRoutes:Routes=[
    {path:"",component:LoginComponent},
    {path:"SinUp", component:SinupComponent},
    {path:"dashBoard", loadChildren:"./modules/dashboard.module#dashboardModule"}
]

export const dashBoardLazyLoad:ModuleWithProviders=RouterModule.forRoot(appRoutes);