import { Component, OnInit } from '@angular/core';
import {  Router } from "@angular/router";
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styles: []
})
export class LoginComponent implements OnInit {
private details:any={"username":"","password":""};  
  constructor(private _router:Router) { }

  ngOnInit() {
  }
  public logIn(obj:any):any{
    console.log(this.details.username+" ******************  "+this.details.password)
        this._router.navigate(["/dashBoard"]);
  }

}
