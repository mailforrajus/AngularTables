import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from "@angular/forms";
import { SinUpService } from "../../services/sinUp.service";
import { HttpErrorResponse } from "@angular/common/http";

@Component({
  selector: 'app-sinup',
  templateUrl: './sinup.component.html'
})
export class SinupComponent implements OnInit {

  countrySubscribe: any;
  contactForm: FormGroup;
  countryList: any;
  statesList: any;
  stateSubscribe: any;
  citiSubscribe: any;
  citiList: any;
  jsonObject: any;

  private result: any;
  constructor(private forBulder: FormBuilder, private _service: SinUpService) {

    this.countryList = this.getCountrysList();
  }
  ngOnInit() {
    this.contactForm = this.forBulder.group({
      email: ['raju@123'],
      mobile: ['9494736031'],
      country: [],
      state: [],
      city: []
    });
  }
  getCountrysList(): any {
    this.countrySubscribe = this._service.getCountryList().subscribe((res): any => {
      this.countryList = res;
    }, this._errorCallBack);
  }

  onSubmit() {

    this.result = this.contactForm.value;
    console.log(this.contactForm.value)
  }

  public onChangeCountry(obj: any): any {
    console.log(obj)
    this.contactForm.value.state = 0;
    this.contactForm.value.city = [];
    console.log(this.contactForm.value.city.value)
    this.stateSubscribe = this._service.getStatesInfo(obj).subscribe((res) => {
      this.statesList = res;
    }, this._errorCallBack);

  }
  public onChangeState(obj: any): any {
    this.contactForm.value.city = 0;
  }
  private _errorCallBack = (err: HttpErrorResponse) => {
    if (err.error instanceof Error) {
      console.log("client side errors");
    } else {
      console.log("server side errors");
    }
  }
}