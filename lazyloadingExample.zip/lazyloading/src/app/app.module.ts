import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { StudentComponentComponent } from './components/student-component/student-component.component';
import { EmployeeComponenComponent } from './components/employee-componen/employee-componen.component';
import { IndexComponent } from './components/index/index.component';
import { RouterModule } from '@angular/router';
import { appRoutes } from './app.routes';
import { EmployeeServicesService } from './services/employee-services.service';
import { StudentService } from './services/student.service';
import { FirstComponentComponent } from './components/first-component/first-component.component';

@NgModule({
  declarations: [
    AppComponent,
    StudentComponentComponent,
    EmployeeComponenComponent,
    IndexComponent,
    FirstComponentComponent
  ],
  imports: [
    BrowserModule, RouterModule.forRoot(appRoutes)
  ],
  providers: [EmployeeServicesService,StudentService],
  bootstrap: [IndexComponent]
})
export class AppModule { }
