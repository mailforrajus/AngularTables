import {  Routes } from "@angular/router";
import {EmployeeComponenComponent  } from "./components/employee-componen/employee-componen.component";
import {  StudentComponentComponent } from "./components/student-component/student-component.component";

export const appRoutes:Routes=[

    {path:"",component:StudentComponentComponent},
    {path:"employeeInfo", component:EmployeeComponenComponent}
]