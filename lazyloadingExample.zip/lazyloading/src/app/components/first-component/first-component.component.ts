import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'Practise-first-component',
  templateUrl: './first-component.component.html',
  styles: []
})
export class FirstComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
