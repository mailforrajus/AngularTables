import { Component, OnInit } from '@angular/core';
import { EmployeeServicesService } from 'src/app/services/employee-services.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-employee-componen',
  templateUrl: './employee-componen.component.html',
  styles: []
})
export class EmployeeComponenComponent implements OnInit {

  private employeesResult:any;
  private employeesSubscribe:any;
  
  constructor(private _employeesService:EmployeeServicesService) { }

  ngOnInit() {
    this.employeesSubscribe=this._employeesService.getAllEmplyees().subscribe(this._successCallBack, this._errorCallBack);


  };
  public _successCallBack=(res)=>{
    this.employeesResult=res;
  };

  public _errorCallBack=(errr:HttpErrorResponse)=>{
    if(errr.error instanceof Error){
      console.log("client side error");
    }else{
      console.log("server side errors");
    }
  };

}
