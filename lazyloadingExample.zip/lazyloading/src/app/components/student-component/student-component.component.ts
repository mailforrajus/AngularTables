import { Component, OnInit } from '@angular/core';
import {  StudentService } from "../../services/student.service";
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-student-component',
  templateUrl: './student-component.component.html'

})
export class StudentComponentComponent implements OnInit {
  public studentResult:any;
  public studentSubscribe:any;

  constructor(private _studentService:StudentService) { };

  ngOnInit() {
    this.studentSubscribe=this._studentService.getAllStudentsInfo().subscribe(this._successCallBack, this._errCallBack);
};
public _successCallBack=(res):any=>{
this.studentResult=res;
};

public _errCallBack=(err:HttpErrorResponse)=>{
  if(err.error instanceof Error){
    console.log("client side errors");
  }else{
    console.log("server side errors")
  }
};
};