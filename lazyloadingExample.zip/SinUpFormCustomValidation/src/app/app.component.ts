import { Component } from '@angular/core';
import { FormGroup, FormBuilder } from "@angular/forms";
import { restService } from './app.service';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
  userRegistrationData: FormGroup;
  private status: any;
  private resutlSubscribe: any;
  constructor(private formbuilder: FormBuilder, private rest: restService) { }

  ngOninit() {
    this.userRegistrationData = this.formbuilder.group({
      userName: '',
      emailId: '',
      aadharNumber: ''
    })
  }

  aadharCardNumberChecck($event): any {
    let val = $event.target.value;
     this.resutlSubscribe=  this.rest.getPincode(val).subscribe(this._successCallBack, this._errorCallBack);
 
  }

  public _successCallBack = (res): any => {
    this.status=res;
    console.log(this.status)
  }
  public _errorCallBack=(err:HttpErrorResponse):any=>{
    if(err.error instanceof Error){
      console.log("Client side errors");
    }else{
      console.log("server side errors..")
    }
  }
  registereDetails(): any {


    console.log(this.userRegistrationData.value);
  }


}
