import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-cases',
  templateUrl: './search-cases.component.html',
  styleUrls: ['./search-cases.component.css']
})
export class SearchCasesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
