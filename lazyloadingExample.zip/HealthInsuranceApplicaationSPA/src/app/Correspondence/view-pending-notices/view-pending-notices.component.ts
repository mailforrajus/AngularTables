import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-pending-notices',
  templateUrl: './view-pending-notices.component.html',
  styleUrls: ['./view-pending-notices.component.css']
})
export class ViewPendingNoticesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
