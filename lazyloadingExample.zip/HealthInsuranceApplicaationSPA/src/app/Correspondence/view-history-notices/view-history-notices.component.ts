import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-history-notices',
  templateUrl: './view-history-notices.component.html',
  styleUrls: ['./view-history-notices.component.css']
})
export class ViewHistoryNoticesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
