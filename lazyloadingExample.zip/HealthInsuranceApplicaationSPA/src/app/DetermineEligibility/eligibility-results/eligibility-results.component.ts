import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eligibility-results',
  templateUrl: './eligibility-results.component.html',
  styleUrls: ['./eligibility-results.component.css']
})
export class EligibilityResultsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
