import { Component, ViewChild, OnInit } from '@angular/core';
import { ApiInfoConsumeServiceService } from './api-info-consume-service.service';
import { MatSort, MatPaginator, MatTableDataSource } from '@angular/material';
import { CaseWorker } from './CaseWorker';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  
  displayedColumns: string[] = ['userId', 'firstName', 'lastName', 'email'];
  caseWorkers: CaseWorker[] = [];
  dataSource: any = new MatTableDataSource(this.caseWorkers);
  result: any;

  constructor(private service: ApiInfoConsumeServiceService) {
    this.service.getCaseworkersInfo().subscribe(data => {
      this.result = data;
      //console.log(this.result.length)
      for (let index = 0; index < this.result.length; index++) {
        this.caseWorkers.push(this.result[index]);
      }
    })
  }

  ngOnInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

}

