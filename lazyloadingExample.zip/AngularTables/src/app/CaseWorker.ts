export interface CaseWorker {
    userId: string
    firstName: string,
    lastName: string,
    email: string;
} 