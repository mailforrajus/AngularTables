import { Injectable } from '@angular/core';
import {   HttpClient} from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class ApiInfoConsumeServiceService {
  private serviceUrl = 'http://localhost:8081/displayAllCaseWorkers';
  constructor(private http:HttpClient) { }

  public getCaseworkersInfo():any{
    return this.http.get(this.serviceUrl);
  }

}
