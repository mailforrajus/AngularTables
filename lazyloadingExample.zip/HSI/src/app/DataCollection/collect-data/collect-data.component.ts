import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-collect-data',
  templateUrl: './collect-data.component.html',
  styleUrls: ['./collect-data.component.css']
})
export class CollectDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
