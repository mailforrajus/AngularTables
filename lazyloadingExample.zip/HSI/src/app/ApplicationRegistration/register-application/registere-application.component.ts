import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registere-application',
  templateUrl: './registere-application.component.html',
  styleUrls: ['./registere-application.component.css']
})
export class RegistereApplicationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
