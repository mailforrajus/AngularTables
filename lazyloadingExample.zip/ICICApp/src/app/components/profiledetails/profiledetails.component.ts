import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profiledetails',
  templateUrl: './profiledetails.component.html',
  styles: []
})
export class ProfiledetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
