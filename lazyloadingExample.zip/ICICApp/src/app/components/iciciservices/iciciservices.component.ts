import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-iciciservices',
  templateUrl: './iciciservices.component.html',
  styles: []
})
export class ICICIServicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
