import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-creditcard',
  templateUrl: './creditcard.component.html',
  styles: []
})
export class CreditcardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
