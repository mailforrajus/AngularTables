import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-statement',
  templateUrl: './account-statement.component.html',
  styles: []
})
export class AccountStatementComponent implements OnInit {

  private accoutnInfo:any;
  constructor() { 
    this.accoutnInfo="this info is from account statement component"
  }

  ngOnInit() {
  }

}
