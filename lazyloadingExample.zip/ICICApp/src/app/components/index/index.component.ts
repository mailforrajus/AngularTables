import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {

  constructor(private _route: Router) { }

  ngOnInit() {
  }
  public home(): any {
    this._route.navigate(["/"]);
  };
  public dashBoard(): any {
    this._route.navigate(["/dashBoard"]);
  };
  public profile(): any {
    this._route.navigate(["/profile"]);
  };
  public services(): any {
    this._route.navigate(["/services"]);
  };
  public personalInfo(): any {
    this._route.navigate(["/personalInfo"]);
  };
  public creditCard(): any {
    this._route.navigate(["/creditCradInfo"]);
  };
  public accountStatement(): any {
    this._route.navigate(["/accountStatementInfo"]);
  };
}
