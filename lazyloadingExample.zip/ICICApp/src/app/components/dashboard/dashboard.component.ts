import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styles: []
})
export class DashboardComponent implements OnInit {

  private dashboardInfo:any;
  constructor() { 
    this.dashboardInfo="welcome to dash board info using lazy loading";
    console.log("inside dashboard component")
  }

  ngOnInit() {
  }

}
