import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sine-up',
  templateUrl: './sine-up.component.html',
  styles: []
})
export class SineUpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
