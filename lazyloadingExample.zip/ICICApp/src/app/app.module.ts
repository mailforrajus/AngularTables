import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {  IndexComponent } from "./components/index/index.component";
import { HomeComponent } from './components/home/home.component';
import {  dashBoardModuleLazyLoad } from './home.routes';
import { LoginandlogoutComponent } from './components/loginandlogout/loginandlogout.component';
import { LoginComponent } from './components/login/login.component';
import { LogoutComponent } from './components/logout/logout.component';
import { SineUpComponent } from './components/sine-up/sine-up.component';


@NgModule({
  declarations: [
    AppComponent,
    IndexComponent,
    HomeComponent,
    LoginandlogoutComponent,
    LoginComponent,
    LogoutComponent,
    SineUpComponent,
   
  ],
  imports: [
    BrowserModule, dashBoardModuleLazyLoad
  ],
  providers: [],
  bootstrap: [IndexComponent]
})
export class AppModule { }
