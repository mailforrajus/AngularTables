import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./components/home/home.component"
import { ModuleWithProviders } from "@angular/core";
import { SineUpComponent } from "./components/sine-up/sine-up.component";

export const homeRoutes: Routes = [
    { path: "", component: HomeComponent },
    { path: "sineUp", component: SineUpComponent },
    { path: "dashBoard", loadChildren: "./lazyLoadModules/dashboard.module#dashBoardModule" },
    { path: "accountStatementInfo", loadChildren: "./lazyLoadModules/accountStatement.module#accountStatementModule" }


];

export const dashBoardModuleLazyLoad: ModuleWithProviders = RouterModule.forRoot(homeRoutes);