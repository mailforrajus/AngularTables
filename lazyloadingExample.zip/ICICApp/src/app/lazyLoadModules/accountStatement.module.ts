import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AccountStatementComponent } from "../components/account-statement/account-statement.component";
import { CommonModule } from "@angular/common";

export const accountStatementRoutes: Routes = [
    { path: "", component: AccountStatementComponent }
];

@NgModule({
    declarations: [AccountStatementComponent],
    imports: [CommonModule, RouterModule.forChild(accountStatementRoutes)],
    providers: [],
    exports: [AccountStatementComponent]
})
export class accountStatementModule {

}
