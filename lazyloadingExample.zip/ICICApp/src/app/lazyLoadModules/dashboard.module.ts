import { NgModule } from "@angular/core";
import { DashboardComponent } from "../components/dashboard/dashboard.component";
import { Routes, RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";

export const dashBoardRoutes: Routes = [
    { path:"",component:DashboardComponent }];
@NgModule({
    declarations: [DashboardComponent],
    imports: [CommonModule, RouterModule.forChild(dashBoardRoutes)],
    providers: [],
    exports: [DashboardComponent]
})
export class dashBoardModule { }