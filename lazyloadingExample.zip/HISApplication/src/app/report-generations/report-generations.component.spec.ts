import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportGenerationsComponent } from './report-generations.component';

describe('ReportGenerationsComponent', () => {
  let component: ReportGenerationsComponent;
  let fixture: ComponentFixture<ReportGenerationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportGenerationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportGenerationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
