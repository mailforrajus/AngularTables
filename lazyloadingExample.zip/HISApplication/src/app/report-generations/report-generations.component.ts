import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-generations',
  templateUrl: './report-generations.component.html',
  styleUrls: ['./report-generations.component.css']
})
export class ReportGenerationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
