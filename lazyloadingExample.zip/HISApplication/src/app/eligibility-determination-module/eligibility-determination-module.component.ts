import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eligibility-determination-module',
  templateUrl: './eligibility-determination-module.component.html',
  styleUrls: ['./eligibility-determination-module.component.css']
})
export class EligibilityDeterminationModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
