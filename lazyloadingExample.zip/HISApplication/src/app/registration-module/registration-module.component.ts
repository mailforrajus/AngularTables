import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from "@angular/forms";
import { ReistrationServiceService } from './reistration-service.service';
import { HttpErrorResponse } from "@angular/common/http";
import { Validators } from "@angular/forms";
@Component({
  selector: 'app-registration-module',
  templateUrl: './registration-module.component.html',
  styleUrls: ['./registration-module.component.css']
})
export class RegistrationModuleComponent implements OnInit {

  registrationInfo: FormGroup;
  resultSubscribe: any;
  resutlInfo: any;
  constructor(private _formBuilder: FormBuilder, private _service: ReistrationServiceService) { }

  ngOnInit() {
    this.registrationInfo = this._formBuilder.group({
      firstName: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(10)]],
      lastName: [],
      dateOfBirth: [],
      emailId: [],
      userId: [],
      mobileNumber: [],
      password: []
    })
  }
  register() {

    this.resultSubscribe = this._service.saveProfileInfo(this.registrationInfo.value).subscribe(this._successCallBack, this._errorCallBack);

  }
  userNameCheck($event) {
    console.log($event.target.value);
  }
  get f() { return this.registrationInfo.controls; }

  public _successCallBack = (res: any): any => {
    this.resutlInfo = res;
    console.log(this.resutlInfo)
  }
  public _errorCallBack = (err: HttpErrorResponse): any => {
    if (err.error instanceof Error) {
      console.log("Client Side errors");
    } else {
      console.log("Server SIde errors" + err);
    }
  }
}
