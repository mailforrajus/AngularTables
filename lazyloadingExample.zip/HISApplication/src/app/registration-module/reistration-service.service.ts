import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ReistrationServiceService {

  constructor(private _httClient: HttpClient) { }
  public saveProfileInfo(resutlInfo:any): any {
    return this._httClient.post("http://localhost:8080/Profile/RestAPI/saveProfileData",resutlInfo);

  }

}
