import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-data-collection-module',
  templateUrl: './data-collection-module.component.html',
  styleUrls: ['./data-collection-module.component.css']
})
export class DataCollectionModuleComponent implements OnInit {

  dataCollectionForm: FormGroup;
  constructor(private formBuilder: FormBuilder) { }

  states:any=[];
  cities:any=[];

  ngOnInit() {
    this.dataCollectionForm = this.formBuilder.group({
      countryName:[],
      stateName:[],
      cityName:[]
    })

  }

}

