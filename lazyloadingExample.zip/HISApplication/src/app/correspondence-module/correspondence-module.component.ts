import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-correspondence-module',
  templateUrl: './correspondence-module.component.html',
  styleUrls: ['./correspondence-module.component.css']
})
export class CorrespondenceModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
