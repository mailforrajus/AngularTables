import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { RegistrationModuleComponent } from './registration-module/registration-module.component';
import { RouterModule } from "@angular/router";
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ReistrationServiceService } from './registration-module/reistration-service.service';
import { HttpClientModule } from '@angular/common/http';
import { DataCollectionModuleComponent } from './data-collection-module/data-collection-module.component';
import { EligibilityDeterminationModuleComponent } from './eligibility-determination-module/eligibility-determination-module.component';
import { CorrespondenceModuleComponent } from './correspondence-module/correspondence-module.component';
import { ReportGenerationsComponent } from './report-generations/report-generations.component';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    RegistrationModuleComponent,
    DataCollectionModuleComponent,
    EligibilityDeterminationModuleComponent,
    CorrespondenceModuleComponent,
    ReportGenerationsComponent
  ],
  imports: [
    BrowserModule, ReactiveFormsModule, RouterModule.forRoot([
      { path: "", component: RegistrationModuleComponent },
      { path: "DcModule", component: DataCollectionModuleComponent },
      { path: "EligibleDeterminationModule", component: EligibilityDeterminationModuleComponent },
      { path: "reportGeneration", component: ReportGenerationsComponent },
      { path: "CorrespondanceModule", component: CorrespondenceModuleComponent }
    ]), HttpClientModule, FormsModule
  ],
  providers: [ReistrationServiceService],
  bootstrap: [HomeComponent]
})
export class AppModule { }
